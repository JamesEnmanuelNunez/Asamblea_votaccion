---
name: Assembly Precision
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eefe'
  surface-container-high: '#e2e8f8'
  surface-container-highest: '#dce2f3'
  on-surface: '#151c27'
  on-surface-variant: '#45464c'
  inverse-surface: '#2a313d'
  inverse-on-surface: '#ebf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#575e70'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#141b2b'
  on-primary-container: '#7d8497'
  inverse-primary: '#c0c6db'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#410004'
  on-tertiary-container: '#ef4444'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce2f7'
  primary-fixed-dim: '#c0c6db'
  on-primary-fixed: '#141b2b'
  on-primary-fixed-variant: '#404758'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce2f3'
typography:
  display-hero:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.011em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.006em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-caps:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
  tally-numeral:
    fontFamily: Geist
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.03em
  seat-id:
    fontFamily: Geist
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers an ultra-minimalist, Swiss-inspired interface tailored for democratic assemblies, parliamentary proceedings, and board governance. The visual language prioritizes absolute clarity, procedural solemnity, and distraction-free cognitive throughput. 

### Design Philosophy
- **Swiss Modernism**: Strict adherence to structural grids, objective typography, asymmetric balance, and uncompromised negative space. Form strictly serves legislative comprehension.
- **Architectural Restraint**: Eliminates decorative ornamentation, skeumorphic flourishes, and superfluous gradients. Depth is conveyed almost entirely via delicate micro-borders and planar value separation.
- **Immediate Legibility**: Assembly status, quorum levels, and voting tallies must be decipherable in fractions of a second from desktop distances and shared projection displays.

## Colors

The color system operates on strict tonal containment to prevent visual fatigue during marathon sessions while reserving high-saturation chromas purely for parliamentary state decisions.

### Light Mode Architecture
- **Canvas Base**: `#F9FAFB` (gray-50) creates an optical cushion, eliminating harsh stark-white glare.
- **Surface Cards**: `#FFFFFF` (pure white) defines elevated interactive voting zones and legislative bills.
- **Structural Lines**: `#E5E7EB` (gray-200) micro-borders demarcate discrete visual cells.
- **Primary Ink**: `#111827` (gray-900) for high-contrast, unyielding textual hierarchy.
- **Secondary Ink**: `#4B5563` (gray-600) for timestamps, seat coordinates, and metadata.

### Dark Mode Architecture
- **Canvas Base**: `#111827` (gray-900) deep charcoal absorbing ambient light.
- **Surface Cards**: `#1F2937` (gray-800) for muted, low-emission component surfaces.
- **Structural Lines**: `rgba(55, 65, 81, 0.8)` (gray-700/80) providing faint structural rhythm without high-contrast distraction.
- **Primary Ink**: `#F3F4F6` (gray-100) balanced against dark grounds to prevent halation.
- **Secondary Ink**: `#9CA3AF` (gray-400) for secondary metrics.

### Semantic Voting Tokens
- **In Favor (Aye)**: `#10B981` (emerald-500). Active green denoting consent.
- **Against (Nay)**: `#EF4444` (red-500). Definitive ruby red denoting dissent.
- **Abstain / Neutral**: `#F59E0B` (amber-500). Controlled amber indicating explicit non-vote.
- **Idle / Unvoted / Absent**: Strict grayscale desaturation (`#9CA3AF` in light mode, `#4B5563` in dark mode) via `filter: grayscale(100%)` and 40% surface opacity to isolate active consensus.

## Typography

Typography is calibrated for instantaneous comprehension and mathematical structure. The dual-sans strategy pairs `Geist` for precise, architectural headings, numeric vote counters, and tracking badges with `Inter` for highly legible motion texts, bill resolutions, and legal clauses.

### Typographic Discipline
- **Tabular Figures**: All numeric data—vote counts, percentages, session timers, and seat numbers—must employ `font-variant-numeric: tabular-nums` to eliminate visual jitter during real-time roll calls.
- **Letter Spacing**: Display and headline levels implement tight tracking (up to `-0.03em`) to anchor the eye. Metadata and label tiers use positive tracking (`0.04em` to `0.08em`) with uppercase transformations for rapid categoric scanning.
- **Hierarchy Encasement**: Legislative docket numbers, quorum status, and protocol tags rely on `label-caps` to distinguish meta-attributes from motion summaries.

## Layout & Spacing

The layout is desktop-first, structured around an asymmetric 16-column assembly master grid optimized for panoramic dashboard resolution (1440px minimum canvas target).

### Grid Configuration
- **Total Columns**: 16 columns with a `1.5rem` (24px) fixed gutter.
- **Canvas Margins**: `2.5rem` (40px) outer edge margins ensuring breathing room against display bezels.
- **Split Ratio**:
  - **Dockets & Motions (Left Pane)**: Spans 6 columns. Hosts the active amendment, legal texts, and author remarks.
  - **Assembly Floor & Tally (Right Pane)**: Spans 10 columns. Visualizes the semicircular chamber floor, seat matrix, real-time counters, and division status.

### Rhythm & Alignment
Internal card layouts adhere to a 4px baseline rhythm. Interactive targets utilize `space-md` padding internally, while grouped assembly benches cluster member avatars with `space-xs` and `space-sm` gaps to simulate spatial density within parliamentary chambers.

## Elevation & Depth

This design system deliberately minimizes physical elevation, rejecting blurred ambient shadows in favor of precise planar geometry, tonal shifts, and low-contrast 1px micro-borders.

### Planar Layers
- **Elevation 0 (Canvas)**: Background canvas (`#F9FAFB` Light / `#111827` Dark).
- **Elevation 1 (Surface Panel)**: Flat 1px outline container (`#FFFFFF` Light / `#1F2937` Dark) framed with `#E5E7EB` (Light) or `rgba(55, 65, 81, 0.8)` (Dark). No shadow.
- **Elevation 2 (Focused Action Modal / Flyout)**: Used exclusively for emergency interventions or voting overrides. Border remains 1px micro-border, accompanied by an ultra-crisp, optical drop: `0px 1px 2px rgba(0, 0, 0, 0.05)`.

### Focused & Cast States
Active member interaction avoids heavy halos. An active voting keypress or selection applies an inner border ring: `box-shadow: inset 0 0 0 1px currentColor`.

## Shapes

The geometric form language communicates institutional gravity. Elements embrace crisp, razor-sharp architectural restraint with near-zero radius values.

- **Level 1 (Soft / Micro-Radii)**: Containers, vote action modules, floor seat nodes, and dialogs apply a disciplined `0.25rem` (4px) corner radius.
- **Assembly Seat Nodes**: Chamber seating matrix modules use either 4px rounded rectangles for desktop consoles or exact circles (`rounded-full`) when representing circular plenary seating plots.
- **Data Dividers**: Straight, hairline 1px strokes with zero terminal rounding.

## Components

### 1. Voting Action Buttons (Aye / Nay / Abstain)
- **Structure**: Large, deliberate hit targets (`height: 56px`, `border-radius: 4px`).
- **In Favor Button**: Light mode background `#FFFFFF`, border `1px solid #E5E7EB`. On hover/active: border `#10B981`, background `#ECFDF5`, text `#065F46`. Dark mode background `#1F2937`, border `1px solid rgba(55, 65, 81, 0.8)`. On hover/active: border `#10B981`, background `rgba(16, 185, 129, 0.1)`, text `#34D399`.
- **Against Button**: Parallel behavior mapped to `#EF4444` (ruby red), transitioning to `#FEF2F2` (Light) or `rgba(239, 68, 68, 0.1)` (Dark).
- **Typography**: Geist Medium with embedded tabular hotkey indicator (e.g., `[ 1 ] AYE`, `[ 2 ] NAY`).

### 2. Assembly Seat Matrix (Chamber Grid)
- **Node Design**: Micro-cards representing members (dimensions: `40px x 40px` or `48px x 48px`).
- **States**:
  - *Voted Aye*: Fill `#10B981`, text `#FFFFFF`.
  - *Voted Nay*: Fill `#EF4444`, text `#FFFFFF`.
  - *Abstained*: Fill `#F59E0B`, text `#FFFFFF`.
  - *Idle / Unvoted*: Filtered through `filter: grayscale(100%)`, opacity `0.4`, surface mapped to Canvas Base with a dashed `1px` border.
- **Hover Detail**: Crisp, instant tooltip exposing member name, party/constituency, and timestamp of cast ballot.

### 3. Tally Visualizer
- **Layout**: Tri-split tabular counter exhibiting Ayes, Nays, and Non-Voting quorums side-by-side.
- **Metrics**: Giant `tally-numeral` (40px) paired with uppercase `label-caps` tracking sub-headers.
- **Quorum Bar**: A single 4px hairline progress bar running horizontally across the bottom edge of the tally card, marking the absolute majority boundary line with a crisp 2px vertical tick.

### 4. Legislative Cards
- **Construction**: 1px micro-bordered surface card (`#FFFFFF` Light / `#1F2937` Dark) containing the active bill or resolution.
- **Header**: Contains metadata pills (`BILL ID`, `READING 3 OF 3`, `TIME REMAINING`) separated by subtle vertical pipes (`|`).
- **Body**: Text set in `body-lg` (Inter) with high line-height for effortless long-form reading under bright chamber lighting.

### 5. Filter Chips & Party Indicators
- **Format**: Border-only pills with `0.25rem` radius. Inactive chips use `#6B7280` text on transparent backgrounds. Active chips take on a high-contrast inverted style: `#111827` fill with white text (Light mode) and `#F9FAFB` fill with dark text (Dark mode).