---
name: Modernist Monograph
colors:
  surface: '#fcf9f2'
  surface-dim: '#dcdad3'
  surface-bright: '#fcf9f2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ec'
  surface-container: '#f1eee7'
  surface-container-high: '#ebe8e1'
  surface-container-highest: '#e5e2db'
  on-surface: '#1c1c18'
  on-surface-variant: '#44474a'
  inverse-surface: '#31312c'
  inverse-on-surface: '#f3f0e9'
  outline: '#75777b'
  outline-variant: '#c5c6ca'
  surface-tint: '#5c5f62'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#191c1f'
  on-primary-container: '#828488'
  inverse-primary: '#c5c6ca'
  secondary: '#006d41'
  on-secondary: '#ffffff'
  secondary-container: '#91f4b8'
  on-secondary-container: '#007144'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#410000'
  on-tertiary-container: '#ee4736'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e2e6'
  primary-fixed-dim: '#c5c6ca'
  on-primary-fixed: '#191c1f'
  on-primary-fixed-variant: '#44474a'
  secondary-fixed: '#94f7bb'
  secondary-fixed-dim: '#78daa0'
  on-secondary-fixed: '#002110'
  on-secondary-fixed-variant: '#005230'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4a8'
  on-tertiary-fixed: '#410000'
  on-tertiary-fixed-variant: '#930001'
  background: '#fcf9f2'
  on-background: '#1c1c18'
  surface-variant: '#e5e2db'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 60px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '500'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: '0'
  body-lg:
    fontFamily: Newsreader
    fontSize: 19px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: '0'
  body-md:
    fontFamily: Newsreader
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: '0'
  body-sm:
    fontFamily: Newsreader
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 3rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system draws direct inspiration from high-modernist Swiss typography, mid-century architectural manifests, and tactile, high-end editorial broadsheets. The aesthetic rejects decorative noise, artificial dimensional skeuomorphism, and digital gradient washes in favor of structural clarity, confident typographic weight contrasts, and deliberate negative space.

### Character & Tone
- **Architectural & Deliberate:** Layouts follow strict structural grids with explicit tectonic relationships. Content is framed rather than floated.
- **Editorial Authority:** Typography takes center stage. High-contrast pairing between an unconventional, geometric grotesque and an authoritative literary serif establishes clear, rhythmic reading hierarchy.
- **Material Restraint:** Color is applied flat, solid, and functional. Surfaces mimic heavy, uncoated archival bone paper with deep obsidian ink typography.

### Emotional Target
The user should feel a sense of disciplined precision, editorial prestige, and tranquil focus. Interactions feel immediate and crisp, like physical broadsheet prints articulated in a modern digital environment.

## Colors

The palette operates strictly on flat, opaque color values. No linear, radial, or mesh gradients are permitted under any condition. Contrast is achieved purely through deliberate juxtaposition of values and razor-sharp border strokes.

### Color Tokens & Assignments
- **Canvas Base (`#FBF9F5`):** The primary paper-like surface tone. Warm, uncoated, anti-fatigue.
- **Surface Elevated (`#F4F1EA`):** Subtle tonal step for secondary containers, tables, and alternating panel fills.
- **Border Crisp (`#E2DDD5`):** The universal structural dividing stroke. Always rendered crisp at 1px width.
- **Primary Ink (`#14171A`):** Deep obsidian charcoal for maximum legibility on text, active icon fills, and primary structural borders.
- **Secondary Ink (`#5C646B`):** Muted carbon for secondary metadata, supporting labels, and captions.
- **Positive Solid (`#1B8755`):** Flat forest emerald reserved strictly for positive voting indicators, success confirmations, and approved statuses.
- **Negative Solid (`#D93829`):** Pure carmine vermilion applied exclusively to negative indicators, downward votes, and destructive actions.
- **Selection / Focus Tint (`#ECE7DC`):** Warm bone accent for hover surfaces, focused rows, and keyboard selection states.

## Typography

The type ecosystem forms a deliberate structural tension: the brutalist, idiosyncratic geometries of **Space Grotesk** act as structural scaffolding, markers, and primary display headers, while the graceful, literary presence of **Newsreader** anchors long-form reading and long-form analysis.

### Structural Pairing Rules
- **Space Grotesk** is reserved for metadata stamps, column indicators, navigation tabs, section anchors, and titles above 32px.
- **Newsreader** carries the weight of all editorial titles, long-form content, quotes, block text, and analytical narratives. Never set Newsreader in all-caps; preserve its organic literary proportions.
- For high-density statistical contexts and tabular voting indices, enforce standard tabular figure alignment (`font-variant-numeric: tabular-nums`).

## Layout & Spacing

Layouts adhere to an architectural modular grid. Spaces are calculated around a consistent 4px/8px baseline rhythm.

### Grid Construction
- **Desktop (1280px+):** 12-column symmetrical fluid grid with a maximum content container width of 1440px. Gutters are fixed at `1.5rem` (24px) with minimum outer margins of `3rem` (48px).
- **Tablet (768px - 1279px):** 8-column layout. Gutters scale to `1.25rem` (20px), outer margins set to `2rem` (32px).
- **Mobile (<768px):** 4-column layout. Gutters compress to `0.75rem` (12px), outer margins set to `1rem` (16px).

### Section Framing
Layout components do not float ambiguously. Columns and distinct functional areas are partitioned by explicit 1px `#E2DDD5` structural rules, mimicking classical broadsheet layout divisions.

## Elevation & Depth

This design system avoids drop shadows, blur-based ambient layering, and simulated 3D depth entirely. Elevation is communicated solely via a combination of two-dimensional architectural mechanisms:

### Depth Mechanics
1. **Low-Contrast Tectonic Lines:** Depth layers and container boundaries are articulated using sharp 1px borders in `#E2DDD5`. 
2. **Solid Inset Tinting:** Elevated or higher-priority containers step from the canvas base (`#FBF9F5`) to the surface background tone (`#F4F1EA`).
3. **Active/Overlay Contrast:** Menus, dropdowns, and flyouts overlay their background using an opaque `#FBF9F5` fill combined with a firm 1px border colored in deep ink (`#14171A`).
4. **No Ambient Diffusion:** Blur radii across all states must remain strictly `0px`. Depth is tactile through boundary, not diffusion.

## Shapes

The shape language is strictly **Sharp (0px radius)**.

- **Zero Curvature:** Buttons, panels, inputs, chips, and overlays are rendered with clean 90-degree orthogonal corners.
- **Architectural Linearity:** The visual weight is carried by hard rectangular geometry, reflecting the physical qualities of paper folios, print galleys, and grid-aligned drafting sheets.
- **Dividers:** Horizontal and vertical divider rules must be rendered as solid, crisp 1px strokes without dashed or dotted stylings.

## Components

### Buttons
- **Primary:** Solid flat fill in `#14171A` with sharp 0px corners, filled with `#FBF9F5` Space Grotesk text (`label-md`). Hover transitions instantly to a solid `#2C3238` background without ease-out gradients.
- **Secondary / Outlined:** `#FBF9F5` fill with a crisp 1px border in `#14171A`, text in `#14171A`. Hover flips the surface to `#F4F1EA`.
- **Voting Buttons:**
  - *Upvote:* 1px border `#E2DDD5` on `#FBF9F5`. When active, transitions to solid `#1B8755` fill with pure white label and icon.
  - *Downvote:* 1px border `#E2DDD5` on `#FBF9F5`. When active, transitions to solid `#D93829` fill with pure white label and icon.

### Chips & Metadata Tags
- **Appearance:** Low-height, rectangular blocks (0px radius) with an explicit 1px `#E2DDD5` border and `#F4F1EA` background.
- **Typography:** Set in Space Grotesk `label-sm` with uppercase tracking (`letter-spacing: 0.08em`).
- **Interactive Variant:** On hover, borders sharpen to `#14171A`.

### Lists & Data Grids
- **Construction:** Divided by continuous 1px `#E2DDD5` lines. No alternating zebra stripes; clean single-value rows.
- **Hover State:** Selected or hovered rows shift flat background fill to `#ECE7DC`.
- **Values:** Numbers and indices utilize Space Grotesk with tabular figures (`tabular-nums`); prose entries remain in Newsreader.

### Form Inputs
- **Appearance:** Solid `#FBF9F5` background, 1px `#E2DDD5` outline, 0px radius.
- **Text:** Input values render in Space Grotesk `body-md` for maximum legibility.
- **Focus:** 1px solid stroke in `#14171A`. Shadows and outer glow rings are prohibited.

### Checkboxes & Radio Controls
- **Checkboxes:** Sharp square box (16x16px), 1px solid border in `#14171A`. When checked, fills solid `#14171A` with a solid white geometric check mark.
- **Radio Buttons:** Sharp concentric square markers (16x16px). When selected, houses an inner solid `#14171A` 8x8px square block.

### Cards & Editorial Panels
- **Framing:** Surrounded by a continuous 1px `#E2DDD5` border with an optional header panel separated by a matching 1px internal rule.
- **Background:** Set flat to `#FBF9F5` or `#F4F1EA`.
- **Content Splitting:** Multi-column content within cards is segmented with vertical 1px `#E2DDD5` rules.